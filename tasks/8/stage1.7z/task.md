You have recived a suspicous file from customer support.

1. Is the file Malicious?

2. If so what does it do?

3. Can you extract som useful IOC's ?
