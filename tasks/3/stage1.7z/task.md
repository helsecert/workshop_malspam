stage1 is encrypted with password "infected" stage2 is encrypted with an IOC found in stage1.

A user in your corporation has raised an alert with a possible infected system, all they can seem to rememeber is clicking on a e-mail.
You have extracted the suspected e-mail, and need to find out what happend.

1. Can you prove that the e-mail is malicious? if so how.
2. What seems to be the payload?
3. What does the payload do?

