1. Investegating the e-mail we can see it's not from DHL
2. The attachment is a .one which is a microsoft onenote.
3. Using strings we can search for embeded objects in onenote,
4. We found som powershell hidden in the file, which downloads a payload from a website and executes that.
5. extract stage.2 with 7z x stage2.7z -phttps://files.catbox.moe/nvz0g1.ps1
6. the rr.ps1 payload contains base64 encoded data which inturn is a in memory execution of malware
7. If we strip all powershell commands from the file, and "" around the payload we can decode it and output it to a file.
which reveals a PE file,file payload.bin 
payload.bin: PE32 executable (DLL) (console) Intel 80386 Mono/.Net assembly, for MS Windows
